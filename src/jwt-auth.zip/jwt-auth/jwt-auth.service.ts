import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { UsersService } from 'src/users/users.service';

@Injectable()
export class JwtAuthService {
  constructor(
    private readonly jwtService: JwtService,
    private usersService: UsersService,
  ) {}
  async createtokenForUser(user: any) {
    const payload = { phoneNumber: user.phoneNumber, sub: user._id };
    return {
      accessToken: this.jwtService.signAsync(payload),
      expiresIn: process.env.JWT_EXPIRES_IN || '3600s',
    };
  }

  findAll() {
    return `This action returns all jwtAuth`;
  }

  findOne(id: number) {
    return `This action returns a #${id} jwtAuth`;
  }

  update() {
    return;
  }

  remove(id: number) {
    return `This action removes a #${id} jwtAuth`;
  }
}
