export class CreateJwtAuthDto {}
