import { Module } from '@nestjs/common';
import { UsersService } from './users.service';
import {
  AuthController,
  UsersController,
  VerifyController,
} from './users.controller';

@Module({
  controllers: [UsersController, AuthController, VerifyController],
  providers: [UsersService],
  exports: [UsersService],
})
export class UsersModule {}
